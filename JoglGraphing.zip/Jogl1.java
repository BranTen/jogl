package p2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLJPanel;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.gl2.GLUT;  // for drawing GLUT objects (such as the teapot)

public class Jogl1 extends JPanel implements GLEventListener, ActionListener {
private GLJPanel display;
    public static void main(String[] args) {
        JFrame win = new JFrame("JOGL");
        Jogl1 panel = new Jogl1();
        win.setContentPane(panel);
        win.pack();
        win.setLocation(50,50);
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.setVisible(true);
    }

    public Jogl1() {
        GLCapabilities caps = new GLCapabilities(null);
        display = new GLJPanel(caps);
        display.setPreferredSize( new Dimension(640,480) );  
        display.addGLEventListener(this);
        setLayout(new BorderLayout());
        add(display,BorderLayout.CENTER);
                requestFocusInWindow();
        startAnimation();
    }

    public void display(GLAutoDrawable dr) {    

		 GL2 gl = dr.getGL().getGL2();
		 gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
		 
		    gl.glLoadIdentity();
		    gl.glTranslatef(-1.5f,0.0f,-12.0f);
		    cube(gl);									//cube
		    
		    
		    gl.glLoadIdentity(); 
		    gl.glTranslatef(2.0f,0.0f,-12.0f);
		    pyramid(gl);								//pyramid
		    	    
		    gl.glLoadIdentity();
		    gl.glTranslatef(-4.5f, 0.0f, -12.0f);			
		    doughnut(gl);								//donut
		     
		    gl.glLoadIdentity();
		    gl.glTranslatef(-4.5f, 2.5f, -12.0f);
		    sphere(gl);									//sphere
		     
		    gl.glLoadIdentity();
		    gl.glTranslatef(2.0f, 3.0f, -12.0f);
		    cylinder(gl);								//cylinder
		     
		    gl.glLoadIdentity();
		    gl.glTranslatef(-1.5f, -3.0f, -12.0f);
		    cone(gl);									//cone		
		    
	    gl.glFlush();
    }

	private float rquad = 0.0f;
	private void cube(GL2 gl) {
		gl.glRotated(rquad, 1.0f, 1.0f, 1.0f);

		gl.glBegin(GL2.GL_QUADS);
		gl.glColor3f(1f, 0f, 0f);
		gl.glVertex3f(1.0f, 1.0f, -1.0f);
		gl.glVertex3f(-1.0f, 1.0f, -1.0f);
		gl.glVertex3f(-1.0f, 1.0f, 1.0f);
		gl.glVertex3f(1.0f, 1.0f, 1.0f);

		gl.glColor3f(0f, 1f, 0f);
		gl.glVertex3f(1.0f, -1.0f, 1.0f);
		gl.glVertex3f(-1.0f, -1.0f, 1.0f);
		gl.glVertex3f(-1.0f, -1.0f, -1.0f);
		gl.glVertex3f(1.0f, -1.0f, -1.0f);

		gl.glColor3f(0f, 0f, 1f);
		gl.glVertex3f(1.0f, 1.0f, 1.0f);
		gl.glVertex3f(-1.0f, 1.0f, 1.0f);
		gl.glVertex3f(-1.0f, -1.0f, 1.0f);
		gl.glVertex3f(1.0f, -1.0f, 1.0f);

		gl.glColor3f(1f, 1f, 0f);
		gl.glVertex3f(1.0f, -1.0f, -1.0f);
		gl.glVertex3f(-1.0f, -1.0f, -1.0f);
		gl.glVertex3f(-1.0f, 1.0f, -1.0f);
		gl.glVertex3f(1.0f, 1.0f, -1.0f);

		gl.glColor3f(1f, 0f, 1f);
		gl.glVertex3f(-1.0f, 1.0f, 1.0f);
		gl.glVertex3f(-1.0f, 1.0f, -1.0f);
		gl.glVertex3f(-1.0f, -1.0f, -1.0f);
		gl.glVertex3f(-1.0f, -1.0f, 1.0f);

		gl.glColor3f(0f, 1f, 1f);
		gl.glVertex3f(1.0f, 1.0f, -1.0f);
		gl.glVertex3f(1.0f, 1.0f, 1.0f);
		gl.glVertex3f(1.0f, -1.0f, 1.0f);
		gl.glVertex3f(1.0f, -1.0f, -1.0f);

		gl.glEnd();
		gl.glFlush();

		rquad -= 2f;
	}
 
	private float rtri = 0.0f;
	private void pyramid(GL2 gl) {

		gl.glRotated(rtri, 1.0f, 1.0f, 0.0f);
		gl.glScalef(0.5f, 0.25f, 0.5f);

		gl.glBegin(GL2.GL_TRIANGLES);

		gl.glColor3f(1.0f, 0.0f, 0.0f);
		gl.glVertex3f(1.0f, 2.0f, 0.0f);
		gl.glVertex3f(-1.0f, -1.0f, 1.0f);
		gl.glVertex3f(1.0f, -1.0f, 1.0f);

		gl.glColor3f(0.0f, 1.0f, 0.0f);
		gl.glVertex3f(1.0f, 2.0f, 0.0f);
		gl.glVertex3f(1.0f, -1.0f, 1.0f);
		gl.glVertex3f(1.0f, -1.0f, -1.0f);

		gl.glColor3f(0.0f, 0.0f, 1.0f);
		gl.glVertex3f(1.0f, 2.0f, 0.0f);
		gl.glVertex3f(1.0f, -1.0f, -1.0f);
		gl.glVertex3f(-1.0f, -1.0f, -1.0f);

		gl.glColor3f(0.0f, 1.0f, 1.0f);
		gl.glVertex3f(1.0f, 2.0f, 0.0f);
		gl.glVertex3f(-1.0f, -1.0f, -1.0f);
		gl.glVertex3f(-1.0f, -1.0f, 1.0f);

		gl.glEnd();

		gl.glFlush();
		rtri += 2.5f;
	}
 
 	private float rdoh = 0.0f;
	private void doughnut(GL2 gl) {
		gl.glRotated(rdoh, 1.0f, 1.0f, 1.0f);

		double cRadius = 0.75;
		double tRadius = .25;

		for (int i = 0; i < 20; i++) {
			double s1 = 0.05 * i;
			double s2 = 0.05 * (i + 1);
			double cCos1 = Math.cos(2 * Math.PI * s1);
			double cSin1 = Math.sin(2 * Math.PI * s1);
			double cCos2 = Math.cos(2 * Math.PI * s2);
			double cSin2 = Math.sin(2 * Math.PI * s2);
			gl.glColor3f(1f, 0f, 1f);
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int j = 0; j <= 5; j++) {
				if (i % 2 == 0) {
					gl.glColor3f(0f, 1f, 1f);
				} else {
					gl.glColor3f(1f, 1f, 0f);
				}
				double t = 0.2 * j;
				double cos = Math.cos(2 * Math.PI * t - Math.PI);
				double sin = Math.sin(2 * Math.PI * t - Math.PI);
				double x1 = cCos1 * (cRadius + tRadius * cos);
				double y1 = cSin1 * (cRadius + tRadius * cos);
				double z1 = sin * tRadius;
				gl.glNormal3d(cCos1 * cos, cSin1 * cos, sin);

				gl.glVertex3d(x1, y1, z1);
				double x2 = cCos2 * (cRadius + tRadius * cos);
				double y2 = cSin2 * (cRadius + tRadius * cos);
				double z2 = sin * tRadius;
				gl.glNormal3d(cCos2 * cos, cSin2 * cos, sin);

				gl.glVertex3d(x2, y2, z2);
			}
			gl.glEnd();
			gl.glFlush();

			rdoh -= 0.5f;

		}
	}

	private float rsph = 0.0f;
	private void sphere(GL2 gl) {
		gl.glRotated(rsph, 0.0f, 0.0f, 1.0f);

		for (int j = 0; j < 20; j++) {
			double lat = (Math.PI / 20) * j - Math.PI / 2;
			double l1 = (Math.PI / 20) * (j + 1) - Math.PI / 2;
			double sL1 = Math.sin(lat);
			double cL1 = Math.cos(lat);
			double sL2 = Math.sin(l1);
			double cL2 = Math.cos(l1);
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int i = 0; i <= 10; i++) {
				if (i % 2 == 0) {
					gl.glColor3f(0f, 0f, 1f);
				} else {

					gl.glColor3f(1f, 0f, 0f);
				}
				double lon = (2 * Math.PI / 10) * i;
				double sL = Math.sin(lon);
				double cL = Math.cos(lon);
				double x1 = cL * cL1;
				double y1 = sL * cL1;
				double z1 = sL1;
				double x2 = cL * cL2;
				double y2 = sL * cL2;
				double z2 = sL2;
				gl.glNormal3d(x2, y2, z2);

				gl.glVertex3d(x2, y2, z2);
				gl.glNormal3d(x1, y1, z1);

				gl.glVertex3d(x1, y1, z1);
			}
			gl.glEnd();
			gl.glFlush();
			rsph += 0.5f;
		}
	}

 	private float rcyl = 0.0f;
 	private void cylinder(GL2 gl) {
		gl.glRotated(rcyl, 1.0f, 1.0f, 1.0f);

		for (int j = 0; j < 10; j++) {
			double z = 0.1 * j;
			double z1 = 0.1 * (j + 1);
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int i = 0; i <= 10; i++) {

				double l = (2 * Math.PI / 10) * i;
				double x = Math.cos(l);
				double y = Math.sin(l);
				gl.glNormal3d(x, y, 0);
				gl.glVertex3d(1 * x, 1 * y, z1);
				gl.glVertex3d(1 * x, 1 * y, z);
			}
			gl.glEnd();
		}
		gl.glNormal3d(0, 0, 1);
		for (int j = 0; j < 5; j++) {
			gl.glColor3f(1f, 0f, 1f);
			double d = 0.2 * j;
			double d1 = 0.2 * (j + 1);
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int i = 0; i <= 10; i++) {
				double a = (2 * Math.PI / 10) * i;
				double sin = Math.sin(a);
				double cos = Math.cos(a);
				gl.glVertex3d(1 * cos * d, 1 * sin * d, 1.0);
				gl.glVertex3d(1 * cos * d1, 1 * sin * d1, 1.0);
			}
			gl.glEnd();
		}
		gl.glNormal3d(0, 0, -1);
		for (int j = 0; j < 5; j++) {

			gl.glColor3f(0f, 1f, 0f);

			double d = 0.2 * j;
			double d1 = 0.2 * (j + 1);
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int i = 0; i <= 10; i++) {
				double a = (2 * Math.PI / 10) * i;
				double sin = Math.sin(a);
				double cos = Math.cos(a);
				gl.glVertex3d(1 * cos * d1, 1 * sin * d1, 0);
				gl.glVertex3d(1 * cos * d, 1 * sin * d, 0);
			}
			gl.glEnd();
			gl.glFlush();
			rcyl += 1f;
		}

    } 
 
 	private float rcon = 0.0f;
	private void cone(GL2 gl) {
		gl.glRotated(rcon, 1.0f, 1.0f, 1.0f);
		gl.glLightf(5, 5, 0.5f);

		for (int j = 0; j < 2; j++) {
			double z = 0.5 * j;
			double z1 = 0.5 * (j + 1);
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int i = 0; i <= 5; i++) {

				gl.glColor3f(1f, 0f, 0f);

				double l = (2 * Math.PI / 5) * i;
				double x = Math.cos(l);
				double y = Math.sin(l);
				double nz = 1.0;
				double length = Math.sqrt(x * x + y * y + nz * nz);
				gl.glNormal3d(x / length, y / length, nz / length);
				gl.glVertex3d((1.0 - z1) / 1.0 * 1.0 * x, (1.0 - z1) / 1.0 * 1.0 * y, z1);
				gl.glVertex3d((1.0 - z) / 1.0 * 1.0 * x, (1.0 - z) / 1.0 * 1.0 * y, z);
			}
			gl.glEnd();
		}
		gl.glNormal3d(0, 0, -1);
		for (int j = 0; j < 1; j++) {
			gl.glColor3f(1f, 1f, 0f);

			double d = 1.0 * j;
			double d1 = 1.0 * (j + 1);
			gl.glBegin(GL2.GL_QUAD_STRIP);
			for (int i = 0; i <= 5; i++) {
				double a = (2 * Math.PI / 5) * i;
				double sin = Math.sin(a);
				double cos = Math.cos(a);
				gl.glVertex3d(1.0 * cos * d1, 1.0 * sin * d1, 0);
				gl.glVertex3d(1.0 * cos * d, 1.0 * sin * d, 0);
			}
			gl.glEnd();
			gl.glFlush();
			rcon += 2f;
		}
	}
    
    public void init(GLAutoDrawable dr) {
        GL2 gl = dr.getGL().getGL2();
    }
    
    private GLU glu = new GLU();
    public void reshape(GLAutoDrawable dr, int x, int y, int w, int h) {

        GL2 gl = dr.getGL().getGL2();

        if(h <= 0)
        	h =1;
        final float hi = (float) w / (float) h;
        gl.glViewport(0, 0, w, h);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(45.0f, hi, 1.0, 20.0);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void dispose(GLAutoDrawable dr) {
		final GL2 gl = dr.getGL().getGL2();
    }

    private int fn = 0;  
    private boolean animate; 
    private Timer at;

    private void updateFrame() {
        fn++;
    }
    
    public void startAnimation() {
        if ( ! animate ) {
            if (at == null) {
                at = new Timer(30, this);
            }
            at.start();
            animate = true;
        }
    }
    
    public void pauseAnimation() {
        if (animate) {
            at.stop();
            animate = false;
        }
    }
    
    public void actionPerformed(ActionEvent e) {
        updateFrame();
        display.repaint();
    }
}